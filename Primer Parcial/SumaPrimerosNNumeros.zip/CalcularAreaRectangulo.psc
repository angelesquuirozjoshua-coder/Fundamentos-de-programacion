Algoritmo CalcularAreaRectangulo
    Definir base, altura, area Como Real
    
    Escribir "Ingrese la base del rect�ngulo:"
    Leer base
    
    Escribir "Ingrese la altura del rect�ngulo:"
    Leer altura
    
    area = base * altura
    
    Escribir "El �rea del rect�ngulo es: ", area
FinAlgoritmo