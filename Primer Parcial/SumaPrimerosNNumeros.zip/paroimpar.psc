Algoritmo paroimpar

    Leer numero
	
    Si numero = 0 Entonces
        Escribir "El n�mero es neutro"
    Sino 
		Si numero MOD 2 = 0 Entonces
			Escribir "El n�mero es par"
		Sino
			Escribir "El n�mero es impar"
		FinSi
	FinSi
	
FinAlgoritmo
