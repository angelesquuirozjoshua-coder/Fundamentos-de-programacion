Algoritmo ahorro
	Definir MN Como Real
	Definir month Como Entero
	Definir end Como Entero
	Definir year 
	
	
FinAlgoritmo
